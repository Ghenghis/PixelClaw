@echo off
echo Uninstalling PixelClaw extension...
code --uninstall-extension pablodelucca.pixel-agents
echo Done.
pause
