@echo off
echo ============================================
echo   PixelClaw v1.0.2 Installer
echo ============================================
echo.

REM Find the VSIX file
for %%f in (*.vsix) do (
    echo Installing %%f into VS Code...
    code --install-extension "%%f"
    if errorlevel 1 (
        echo.
        echo ERROR: Failed to install extension.
        echo Make sure VS Code is installed and 'code' is in your PATH.
        pause
        exit /b 1
    )
    echo.
    echo SUCCESS: PixelClaw extension installed!
    echo.
    echo Open VS Code and look for the Pixel Agents panel in the bottom panel area.
    echo.
    pause
    exit /b 0
)

echo ERROR: No .vsix file found in this directory.
pause
exit /b 1
